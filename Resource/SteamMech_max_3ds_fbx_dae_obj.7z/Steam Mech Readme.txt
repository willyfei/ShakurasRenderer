Steam Mech Transport
by S.A.Maynard

A walking transportation vehicle from another time period or alternative universe. Item is in OBJ, FBX, 3DS and DAE file formats and has texture files. Item is not scaled for any particular application. Item can be used for personal renders and projects only, no commercial use.